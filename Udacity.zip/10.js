var rainbow = ['Red', 'Orange', 'Blackberry', 'Blue'];

// your code goes here
rainbow.splice(2,1, "Yellow", "Green");
rainbow.splice(5,0, "Purple");