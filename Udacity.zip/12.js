var breakfast = {
    name: "The Lumberjack",
    price:9.95,
    ingredients: ["eggs", "sausage", "toast", "hashbrowns", "pancakes"]
};