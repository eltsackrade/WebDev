for(var x = 5; x <= 9; x++){
    console.log(x);
}