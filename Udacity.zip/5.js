function laugh(num){
    var hah = "";
    var haha = "ha";
    for(var i = 1; i<=num; i++){
        hah+=haha;
    }
    hah+="!";
    return hah;
}

var num = 3;

console.log(laugh(num));