function makeLine(length) {
    var line = "";
    for (var j = 1; j <= length; j++) {
        line += "* ";
    }
    return line + "\n";
}

function buildTriangle(height){
    var ans = "";
    for(var i = 1; i <= height; i++){
        ans += makeLine(i);
    }
    return ans;
    
}

console.log(buildTriangle(10));