var udaciFamily = ["Julia", "James", "Dina"];

for(var i = 0; i < udaciFamily.length; i++){
    console.log(udaciFamily[i]);
}
